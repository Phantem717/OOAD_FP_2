module Final_Project_OOAD {
	requires javafx.graphics;
	requires javafx.controls;
	requires javafx.base;
	requires java.sql;

	opens main;
	opens Util;
	
}