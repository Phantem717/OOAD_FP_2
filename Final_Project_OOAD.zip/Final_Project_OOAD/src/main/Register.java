package main;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Register {
	Scene scene;
	Label titleLBL, passwordLBL, usernameLBL,addressLBL,phoneNumberLBL,rolesLBL;
	BorderPane borderContainer;
	GridPane gridContainer;
	FlowPane flowContainer;
	TextField usernameTXT,phoneNumberTXT,addressTXT;
	PasswordField passwordTXT;
	Button submitBtn;
	RadioButton seller,buyer,admin;
	Stage stage;
	
	
	void initialize() {
		titleLBL = new Label("Register Here");
		passwordLBL = new Label("Password");
		usernameLBL = new Label("UserName");
		addressLBL = new Label("Address");
		phoneNumberLBL = new Label("Phone Number");
		rolesLBL = new Label("Roles");
		
		borderContainer = new BorderPane();
		flowContainer = new FlowPane();
		gridContainer = new GridPane();
	
		usernameTXT = new TextField();
		passwordTXT = new PasswordField();
		phoneNumberTXT = new TextField();
		addressTXT = new TextField();
		submitBtn = new Button("Register");
		seller = new RadioButton("Seller");
		buyer = new RadioButton("Buyer");
		admin = new RadioButton("Admin");
		ToggleGroup group = new ToggleGroup();
		seller.setToggleGroup(group);
		buyer.setToggleGroup(group);
		admin.setToggleGroup(group);
		
		
		scene = new Scene(borderContainer,600,400);
		
	}
	void addComponent() {
		borderContainer.setTop(titleLBL);
		borderContainer.setCenter(gridContainer);
		gridContainer.add(usernameLBL, 0, 1);
		gridContainer.add(passwordLBL, 0, 2);
		gridContainer.add(phoneNumberLBL, 0, 3);
		gridContainer.add(addressLBL, 0, 4);
		gridContainer.add(rolesLBL, 0, 5);
		gridContainer.add(flowContainer, 1, 0);
		gridContainer.add(usernameTXT, 1,1);
		gridContainer.add(passwordTXT, 1, 2);
		gridContainer.add(phoneNumberTXT, 1, 3);
		gridContainer.add(addressTXT, 1, 4);
		gridContainer.add(buyer, 1, 5);
		gridContainer.add(seller, 1, 6);
		gridContainer.add(admin, 1, 7);
		borderContainer.setBottom(submitBtn);
		
	}
	public void initaction() {
		
		submitBtn.setOnAction(e -> {
			new HomeBuyer(stage);
		});
	}
	void arrageComponents() {
		
		usernameTXT.setMinWidth(100);
		passwordTXT.setMinWidth(100);
		addressTXT.setMinWidth(100);
		phoneNumberTXT.setMinWidth(100);
	
		usernameTXT.setMaxWidth(300);
		passwordTXT.setMaxWidth(300);
		addressTXT.setMaxWidth(300);
		phoneNumberTXT.setMaxWidth(300);
		
		BorderPane.setAlignment(titleLBL, Pos.CENTER);
		BorderPane.setAlignment(gridContainer, Pos.CENTER);
		BorderPane.setAlignment(flowContainer, Pos.CENTER);
	BorderPane.setAlignment(submitBtn, Pos.CENTER);
	gridContainer.setAlignment(Pos.CENTER);
	borderContainer.setPadding(new Insets(10));
	flowContainer.setHgap(10);
	gridContainer.setHgap(30);
	gridContainer.setVgap(10);
	titleLBL.setPadding(new Insets(5));
	submitBtn.setPadding(new Insets(5));
//	fasfaf
	
//	fafasfaf
	}
	
	public Register(Stage arg0) {
		initialize();
		addComponent();
		arrageComponents();
		initaction();
		 
	        this.stage = arg0;
	        arg0.setScene(scene);
	        arg0.show();
	}

}
